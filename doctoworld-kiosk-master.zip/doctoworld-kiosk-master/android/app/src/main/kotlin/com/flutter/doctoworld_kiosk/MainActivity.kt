package com.flutter.doctoworld_kiosk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
