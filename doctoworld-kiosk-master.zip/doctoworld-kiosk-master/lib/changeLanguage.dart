import 'package:animation_wrappers/animation_wrappers.dart';
import '../Auth/login_navigator.dart';
import '../Components/custom_button.dart';
import '../Config/app_config.dart';
import '../Locale/language_cubit.dart';
import '../Locale/locale.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ChangeLanguagePage extends StatefulWidget {
  final bool fromRoot;

  ChangeLanguagePage([this.fromRoot = true]);

  @override
  _ChangeLanguagePageState createState() => _ChangeLanguagePageState();
}

class _ChangeLanguagePageState extends State<ChangeLanguagePage> {
  late LanguageCubit _languageCubit;
  String? selectedLocal;

  @override
  void initState() {
    super.initState();
    _languageCubit = BlocProvider.of<LanguageCubit>(context);
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LanguageCubit, Locale>(
      builder: (context, locale) {
        return Scaffold(
          appBar: AppBar(
            titleSpacing: 0,
            centerTitle: true,
            title: Text(
              AppLocalizations.of(context)!.changeLanguage!,
              style: Theme.of(context)
                  .textTheme
                  .bodyText2!
                  .copyWith(fontSize: 17, fontWeight: FontWeight.w700),
            ),
            textTheme: Theme.of(context).textTheme,
          ),
          body: FadedSlideAnimation(
            Stack(
              children: [
                ListView(
                  children: [
                    BlocBuilder<LanguageCubit, Locale>(
                      builder: (context, currentLocale) {
                        selectedLocal ??= currentLocale.languageCode;
                        return ListView.builder(
                          physics: NeverScrollableScrollPhysics(),
                          itemCount: AppConfig.languagesSupported.length,
                          shrinkWrap: true,
                          itemBuilder: (context, index) => RadioListTile(
                            value: AppConfig.languagesSupported.keys
                                .elementAt(index),
                            groupValue: selectedLocal,
                            title: Text(
                              AppConfig
                                  .languagesSupported[AppConfig
                                      .languagesSupported.keys
                                      .elementAt(index)]!
                                  .name,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText2!
                                  .copyWith(
                                    fontSize: 15,
                                  ),
                            ),
                            onChanged: (langCode) => setState(
                                () => selectedLocal = langCode as String),
                          ),
                        );
                      },
                    ),
                  ],
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: CustomButton(
                      text: 'Continue',
                      onTap: () {
                        _languageCubit.setCurrentLanguage(selectedLocal!, true);
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => LoginNavigator()));
                      }),
                ),
              ],
            ),
            beginOffset: Offset(0, 0.3),
            endOffset: Offset(0, 0),
            slideCurve: Curves.linearToEaseOut,
          ),
        );
      },
    );
  }
}
