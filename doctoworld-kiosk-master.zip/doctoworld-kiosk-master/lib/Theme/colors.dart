import 'package:flutter/material.dart';

final Color kMainColor = Color(0xff0fc1a7);
final Color kLightHintColor = Color(0xffa7a7a7);
final Color kTextFieldLabelColor = Color(0xff838383);
final Color kTransparentColor = Colors.transparent;
final Color starColor = Colors.yellow;
final Color  dayTimeTextBackground = Color(0xfff4f7f8);
final Color dayTimeTextColor = Color(0xffababab);