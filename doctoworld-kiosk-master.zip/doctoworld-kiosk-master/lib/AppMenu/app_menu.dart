import 'package:animation_wrappers/animation_wrappers.dart';
// import 'package:buy_this_app/buy_this_app.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:doctoworld_kiosk/Routes/routes.dart';
import 'package:doctoworld_kiosk/Theme/colors.dart';
import 'package:flutter/material.dart';

import '../Config/app_config.dart';

class AppMenu extends StatefulWidget {
  @override
  _AppMenuState createState() => _AppMenuState();
}

class MenuItem {
  String text;
  String? text2;
  String image;
  Function onTap;

  MenuItem(this.text, this.text2, this.image, this.onTap);
}

class _AppMenuState extends State<AppMenu> {
  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    List<MenuItem> menuItems = [
      MenuItem(locale.our! + '\n', locale.doctors, 'assets/menu/Layer 1540.png',
          () {
        Navigator.pushNamed(context, PageRoutes.ourDoctorsPage);
      }),
      MenuItem(
          locale.our! + '\n', locale.departments, 'assets/menu/Layer 1539.png',
          () {
        Navigator.pushNamed(context, PageRoutes.ourDepartmentsPage);
      }),
      MenuItem(
          locale.pharmacy! + '\n', locale.nearMe, 'assets/menu/Layer 1541.png',
          () {
        Navigator.pushNamed(context, PageRoutes.pharmacyNearMe);
      }),
      MenuItem(locale.contact! + '\n', locale.us, 'assets/menu/Layer 1542.png',
          () {
        Navigator.pushNamed(context, PageRoutes.contactUsPage);
      }),
    ];
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColorLight,
      body: Padding(
        padding: const EdgeInsets.only(top: 38.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Text(
                locale.welcome!,
                style: Theme.of(context)
                    .textTheme
                    .headline4!
                    .copyWith(color: Theme.of(context).scaffoldBackgroundColor),
              ),
            ),
            SizedBox(
              height: 8,
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Text(
                locale.letUsGuide!,
                style: Theme.of(context)
                    .textTheme
                    .caption!
                    .copyWith(color: Theme.of(context).scaffoldBackgroundColor),
              ),
            ),
            SizedBox(
              height: 8,
            ),
            GridView.builder(
                padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 20.0),
                itemCount: menuItems.length,
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 20,
                    mainAxisSpacing: 20),
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: menuItems[index].onTap as void Function()?,
                    child: Material(
                      borderRadius: BorderRadius.circular(8),
                      elevation: 10,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: Theme.of(context).scaffoldBackgroundColor,
                        ),
                        child: Padding(
                          padding: const EdgeInsetsDirectional.only(
                              start: 16.0, top: 16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RichText(
                                  text: TextSpan(children: [
                                TextSpan(
                                    text: menuItems[index].text.toUpperCase(),
                                    style: index < 2
                                        ? Theme.of(context)
                                            .textTheme
                                            .bodyText2!
                                            .copyWith(letterSpacing: 1)
                                        : Theme.of(context)
                                            .textTheme
                                            .bodyText1!
                                            .copyWith(letterSpacing: 1)),
                                TextSpan(
                                    text: menuItems[index].text2!.toUpperCase(),
                                    style: index < 2
                                        ? Theme.of(context)
                                            .textTheme
                                            .bodyText1!
                                            .copyWith(letterSpacing: 1)
                                        : Theme.of(context)
                                            .textTheme
                                            .bodyText2!
                                            .copyWith(letterSpacing: 1)),
                              ])),
                              Spacer(),
                              FadedScaleAnimation(
                                Image.asset(menuItems[index].image),
                                durationInMilliseconds: 400,
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                }),
            Expanded(
              child: Stack(
                alignment: AlignmentDirectional.bottomCenter,
                children: [
                  FadedScaleAnimation(
                    Image.asset(
                      'assets/app_menu_main.png',
                      height: 260,
                      width: double.infinity,
                      fit: BoxFit.cover,
                      alignment: Alignment.bottomCenter,
                    ),
                    durationInMilliseconds: 400,
                  ),
                  Container(
                    height: 260,
                    width: double.infinity,
                    decoration: BoxDecoration(
                        gradient: LinearGradient(
                      colors: [
                        Theme.of(context).primaryColorLight,
                        Colors.white10,
                        kTransparentColor,
                        kTransparentColor,
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    )),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      // floatingActionButton: AppConfig.isDemoMode
      //     ? Container(
      //         padding: const EdgeInsets.all(20),
      //         child: BuyThisApp.button(
      //           AppConfig.appName,
      //           'https://dashboard.vtlabs.dev/projects/envato-referral-buy-link?project_slug=doctoworld_flutter',
      //         ))
      //     : null,
      // bottomNavigationBar: AppConfig.isDemoMode
      //     ? Container(
      //         padding: const EdgeInsets.all(8),
      //         child: BuyThisApp.developerRowOpus(
      //             Colors.transparent, Theme.of(context).primaryColor),
      //       )
      //     : const SizedBox.shrink(),
    );
  }
}
