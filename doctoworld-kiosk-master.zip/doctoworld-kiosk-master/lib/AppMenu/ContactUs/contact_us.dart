import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_kiosk/Components/custom_button.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:doctoworld_kiosk/Theme/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ContactUsPage extends StatefulWidget {
  @override
  _ContactUsPageState createState() => _ContactUsPageState();
}

class _ContactUsPageState extends State<ContactUsPage> {
  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    return Scaffold(
      backgroundColor: dayTimeTextBackground,
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.chevron_left)),
        title: Text(locale.contactUs!),
        centerTitle: true,
      ),
      body: FadedSlideAnimation(
        Stack(
          children: [
            ListView(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              children: [
                SizedBox(
                  height: 12,
                ),
                Text(
                  locale.howMayWe! + '\n' + locale.helpYou!,
                  style: Theme.of(context)
                      .textTheme
                      .headline5!
                      .copyWith(fontWeight: FontWeight.w600, fontSize: 28),
                ),
                SizedBox(
                  height: 18,
                ),
                Text(
                  locale.letUsKnowYourQueriesFeedbacks!,
                  style: Theme.of(context)
                      .textTheme
                      .caption!
                      .copyWith(fontSize: 15),
                ),
                SizedBox(
                  height: 36,
                ),
                ListTile(
                  tileColor: Theme.of(context).scaffoldBackgroundColor,
                  leading: Icon(
                    Icons.call,
                    color: Theme.of(context).primaryColor,
                    size: 30,
                  ),
                  title: Text(
                    locale.callUs!,
                    style: Theme.of(context).textTheme.caption,
                  ),
                  subtitle: Text(
                    '+1 987 654 3210',
                    style: Theme.of(context).textTheme.bodyText1,
                  ),
                ),
                SizedBox(
                  height: 12,
                ),
                ListTile(
                  tileColor: Theme.of(context).scaffoldBackgroundColor,
                  leading: Icon(
                    Icons.email,
                    color: Theme.of(context).primaryColor,
                    size: 30,
                  ),
                  title: Text(
                    locale.emailUs!,
                    style: Theme.of(context).textTheme.caption,
                  ),
                  subtitle: Text(
                    'help@hospiatlname.com',
                    style: Theme.of(context).textTheme.bodyText1,
                  ),
                ),
                SizedBox(
                  height: 40,
                ),
                CustomButton(
                  text: 'Submit',
                  onTap: () {
                    Navigator.pop(context);
                  },
                ),
                SizedBox(
                  height: 20,
                ),
              ],
            ),
            PositionedDirectional(
              bottom: 0,
              start: 0,
              end: 0,
              child: FadedScaleAnimation(
                Image.asset('assets/contact us.png'),
                durationInMilliseconds: 400,
              ),
            ),
          ],
        ),
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
      ),
    );
  }
}
