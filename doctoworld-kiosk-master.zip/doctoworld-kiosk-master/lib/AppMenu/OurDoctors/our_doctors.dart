import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:doctoworld_kiosk/Routes/routes.dart';
import 'package:flutter/material.dart';

class OurDoctors extends StatefulWidget {
  @override
  _OurDoctorsState createState() => _OurDoctorsState();
}

class _OurDoctorsState extends State<OurDoctors> {
  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    return Scaffold(
        appBar: AppBar(
          leading: IconButton(
              onPressed: () => Navigator.pop(context),
              icon: Icon(Icons.chevron_left)),
          title: Text(locale.ourDoctors!),
          centerTitle: true,
        ),
        body: FadedSlideAnimation(
          DoctorsBody(),
          beginOffset: Offset(0, 0.3),
          endOffset: Offset(0, 0),
          slideCurve: Curves.linearToEaseOut,
        ));
  }
}

class DoctorsBody extends StatefulWidget {
  @override
  _DoctorsBodyState createState() => _DoctorsBodyState();
}

class _DoctorsBodyState extends State<DoctorsBody> {
  List<String> specialities = [
    'Addiction psychiatrist',
    'Adolescent medicine specialist',
    'Allergist (immunologist)',
    'Anesthesiologist',
    'Bariatric Surgery',
    'Brain Injury Medicine',
    'Breast Surgery',
    'Burn surgery',
    'Cardiac Electrophysiology',
    'Brain Injury Medicine',
    'Breast Surgery',
    'Burn surgery',
    'Cardiac Electrophysiology',
  ];
  List<String> doctorCategories = [
    'assets/specialities/ayurvedic.png',
    'assets/specialities/dental.png',
    'assets/specialities/hospital.png',
    'assets/specialities/thrapist.png',
    'assets/specialities/ayurvedic.png',
    'assets/specialities/dental.png',
    'assets/specialities/hospital.png',
    'assets/specialities/thrapist.png',
  ];
  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    return Scaffold(
      body: ListView(
        physics: BouncingScrollPhysics(),
        children: <Widget>[
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
            child: Text(
              locale.findBySpecialities!.toUpperCase(),
              style: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .copyWith(color: Theme.of(context).disabledColor),
            ),
          ),
          Container(
            height: 123.3,
            margin: EdgeInsets.only(left: 10),
            child: ListView.builder(
                shrinkWrap: true,
                physics: BouncingScrollPhysics(),
                scrollDirection: Axis.horizontal,
                itemCount: doctorCategories.length,
                itemBuilder: (context, index) {
                  return InkWell(
                    onTap: () {
                      Navigator.pushNamed(context, PageRoutes.listOfDoctors);
                    },
                    child: Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: FadedScaleAnimation(
                        Image.asset(
                          doctorCategories[index],
                          height: 100,
                          width: 95,
                          fit: BoxFit.fill,
                        ),
                        durationInMilliseconds: 400,
                      ),
                    ),
                  );
                }),
          ),
          SizedBox(
            height: 5,
          ),
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 20.0),
            child: Text(
              locale.listOfSpecialities!.toUpperCase(),
              style: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .copyWith(color: Theme.of(context).disabledColor),
            ),
          ),
          ListView.builder(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: specialities.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(
                    vertical: 12.0, horizontal: 16.0),
                child: Text(
                  specialities[index],
                  style: Theme.of(context)
                      .textTheme
                      .bodyText2!
                      .copyWith(fontSize: 14,fontWeight: FontWeight.bold),
                ),
              );
              /*ListTile(
                contentPadding: EdgeInsets.symmetric(),
                title: Text('Addiction psychiatrist'),
                trailing: Icon(Icons.arrow_forward_ios, size: 15,),
              );*/
            },
          ),
        ],
      ),
    );
  }
}
