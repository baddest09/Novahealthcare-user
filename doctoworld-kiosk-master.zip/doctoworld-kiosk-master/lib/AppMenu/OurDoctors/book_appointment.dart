import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_kiosk/Components/custom_button.dart';
import 'package:doctoworld_kiosk/Components/entry_field2.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:doctoworld_kiosk/Routes/routes.dart';
import 'package:doctoworld_kiosk/Theme/colors.dart';
import 'package:flutter/material.dart';

class BookAppointmentPage extends StatefulWidget {
  @override
  _BookAppointmentPageState createState() => _BookAppointmentPageState();
}

class _BookAppointmentPageState extends State<BookAppointmentPage> {
  bool verificationCodeSent = false;
  final List<String> day = [
    'Mon',
    'Tues',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
    'Mon',
    'Tues',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
    'Mon',
    'Tues',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
    'Mon',
    'Tues',
    'Wed',
    'Thu',
    'Fri',
    'Sat',
    'Sun',
  ];
  final List<String> time = [
    '7:00',
    '8:00',
    '9:00',
    '10:00',
    '11:00',
  ];
  int? _selectedDate;
  int? _selectedTime;

  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.chevron_left)),
        title: Text(locale.selectDateTime!),
        centerTitle: true,
      ),
      body: FadedSlideAnimation(
        Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20.0),
                    child: Row(
                      children: [
                        Text(
                          locale.selectDate!,
                          style: Theme.of(context)
                              .textTheme
                              .caption!
                              .copyWith(fontSize: 16),
                        ),
                        Spacer(),
                        Text(
                          locale.june2020!,
                          style: Theme.of(context)
                              .textTheme
                              .bodyText1!
                              .copyWith(fontSize: 16),
                        )
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 100,
                    child: ListView.builder(
                      padding:
                          EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                      scrollDirection: Axis.horizontal,
                      shrinkWrap: true,
                      itemCount: 28,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            setState(() {
                              _selectedDate = index;
                            });
                          },
                          child: FadedScaleAnimation(
                            Container(
                              width: 55,
                              margin: EdgeInsets.only(right: 8, bottom: 10),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 6),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: _selectedDate == index
                                    ? Theme.of(context).primaryColor
                                    : Color(0xfff8f9fd),
                              ),
                              child: RichText(
                                  textAlign: TextAlign.center,
                                  text: TextSpan(children: <TextSpan>[
                                    TextSpan(
                                      text: '${index + 1}\n',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyText1!
                                          .copyWith(
                                            fontSize: 21,
                                            color: _selectedDate == index
                                                ? Theme.of(context)
                                                    .scaffoldBackgroundColor
                                                : Colors.black,
                                          ),
                                    ),
                                    TextSpan(
                                      text: day[index],
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyText1!
                                          .copyWith(
                                            fontSize: 11,
                                            color: _selectedDate == index
                                                ? Theme.of(context)
                                                    .scaffoldBackgroundColor
                                                : dayTimeTextColor,
                                          ),
                                    ),
                                  ])),
                            ),
                            durationInMilliseconds: 400,
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    height: 4,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 8),
                    child: Text(
                      locale.selectTime!,
                      style: Theme.of(context)
                          .textTheme
                          .caption!
                          .copyWith(fontSize: 16),
                    ),
                  ),
                  SizedBox(
                    height: 70,
                    child: ListView.builder(
                      padding:
                          EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      scrollDirection: Axis.horizontal,
                      shrinkWrap: true,
                      itemCount: 5,
                      itemBuilder: (context, index) {
                        return GestureDetector(
                          onTap: () {
                            setState(
                              () {
                                _selectedTime = index;
                              },
                            );
                          },
                          child: FadedScaleAnimation(
                            Container(
                              margin: EdgeInsets.only(right: 6, bottom: 8),
                              padding: EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 8),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(12),
                                color: _selectedTime == index
                                    ? Theme.of(context).primaryColor
                                    : Color(0xfff8f9fd),
                              ),
                              child: RichText(
                                text: TextSpan(
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: time[index],
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyText1!
                                          .copyWith(
                                            fontSize: 18,
                                            color: _selectedTime == index
                                                ? Colors.white
                                                : Colors.black,
                                          ),
                                    ),
                                    TextSpan(
                                      text: ' ' + locale.am!,
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodyText1!
                                          .copyWith(
                                            fontSize: 11,
                                            color: _selectedTime == index
                                                ? Theme.of(context)
                                                    .scaffoldBackgroundColor
                                                : dayTimeTextColor,
                                          ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            durationInMilliseconds: 400,
                          ),
                        );
                      },
                    ),
                  ),
                  SizedBox(
                    height: 12,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                        left: 12.0, right: 20.0, bottom: 28.0),
                    child: EntryField2(
                      label: locale.appointmentFor!.toUpperCase(),
                      hint: locale.egHeart,
                    ),
                  ),
                  Divider(
                    height: 6,
                    thickness: 6,
                  ),
                  !verificationCodeSent
                      ? Padding(
                          padding: const EdgeInsets.only(
                              left: 12.0, right: 20.0, bottom: 20.0, top: 28.0),
                          child: EntryField2(
                            label: locale.fullName!.toUpperCase(),
                            textEditingController:
                                TextEditingController(text: 'Samantha Smith'),
                          ),
                        )
                      : Padding(
                          padding: const EdgeInsets.only(
                              left: 20.0, right: 20.0, bottom: 20.0, top: 28.0),
                          child: Text(
                            locale.enterOTPSentOnYour! +
                                '\n' +
                                locale.givenNumber!,
                            style: Theme.of(context).textTheme.headline6,
                          ),
                        ),
                  !verificationCodeSent
                      ? Padding(
                          padding: const EdgeInsets.only(
                              left: 12.0, right: 20.0, bottom: 20.0, top: 20.0),
                          child: EntryField2(
                            label: locale.phoneNumber!.toUpperCase(),
                            textEditingController:
                                TextEditingController(text: '+1 987 654 3210'),
                          ),
                        )
                      : Padding(
                          padding: const EdgeInsets.only(
                              left: 12.0, right: 20.0, bottom: 20.0, top: 20.0),
                          child: EntryField2(
                            label: locale.enterOTP!.toUpperCase(),
                            textEditingController:
                                TextEditingController(text: '587163'),
                          ),
                        ),
                  !verificationCodeSent
                      ? Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24.0),
                          child: Text(
                            locale.wellSendVerificationCode!,
                            style: Theme.of(context).textTheme.caption,
                          ),
                        )
                      : SizedBox.shrink(),
                  SizedBox(
                    height: 70,
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: CustomButton(
                text: !verificationCodeSent
                    ? locale.sendVerificationCode
                    : locale.confirmBooking,
                onTap: () {
                  verificationCodeSent
                      ? Navigator.pushNamed(
                          context, PageRoutes.appointmentBookedPage)
                      : null;
                  setState(() {
                    verificationCodeSent = true;
                  });
                },
              ),
            )
          ],
        ),
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
      ),
    );
  }
}
