import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:doctoworld_kiosk/Routes/routes.dart';
import 'package:flutter/material.dart';

class AppointmentBooked extends StatefulWidget {
  @override
  _AppointmentBookedState createState() => _AppointmentBookedState();
}

class _AppointmentBookedState extends State<AppointmentBooked> {
  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.chevron_left)),
        title: Text(locale.appointmentBooked!),
        automaticallyImplyLeading: false,
        centerTitle: true,
      ),
      body: FadedSlideAnimation(
        Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Spacer(),
            Expanded(
              flex: 5,
              child: FadedScaleAnimation(
                Image.asset(
                  'assets/order placed.png',
                  // scale: 3,
                ),
                durationInMilliseconds: 400,
              ),
            ),
            Spacer(),
            Center(
                child: Text(
              locale.yourAppointmentHas! + '\n' + locale.beenBooked!,
              style:
                  Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 18),
              textAlign: TextAlign.center,
            )),
            Spacer(),
            Center(
                child: Text(
                    locale.appointmentDetails! +
                        '\n' +
                        locale.hasBeenSentOnYourGiven! +
                        '\n' +
                        locale.number!,
                    style: Theme.of(context)
                        .textTheme
                        .caption!
                        .copyWith(fontSize: 16),
                    textAlign: TextAlign.center)),
            Spacer(
              flex: 3,
            ),
            Center(
                child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(context, PageRoutes.appMenu);
                  },
                  child: Text(
                    locale.home!,
                    style: Theme.of(context).textTheme.bodyText1!.copyWith(
                        fontSize: 16, color: Theme.of(context).primaryColor),
                  )),
            ))
          ],
        ),
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
      ),
    );
  }
}
