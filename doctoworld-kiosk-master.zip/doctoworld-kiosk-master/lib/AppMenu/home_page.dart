import 'package:animation_wrappers/Animations/faded_scale_animation.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:doctoworld_kiosk/Routes/routes.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    return Scaffold(
      backgroundColor: Theme.of(context).backgroundColor,
      body: GestureDetector(
        onTap: () {
          Navigator.pushNamed(context, PageRoutes.appMenu);
        },
        child: Column(
          children: [
            Spacer(
              flex: 2,
            ),
            Image.asset(
              'assets/app_name2.png',
              scale: 2,
            ),
            Spacer(),
            RichText(
                text: TextSpan(children: [
              TextSpan(
                  text: '10:00',
                  style: Theme.of(context).textTheme.headline2!.copyWith(
                      color: Theme.of(context).scaffoldBackgroundColor)),
              TextSpan(
                  text: ' ' + '\u1d56\u1d50',
                  style: Theme.of(context).textTheme.headline3!.copyWith(
                      color: Theme.of(context).scaffoldBackgroundColor)),
            ])),
            Spacer(
              flex: 2,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: FadedScaleAnimation(
                Image.asset('assets/img_home.png'),
                durationInMilliseconds: 400,
              ),
            ),
            Spacer(
              flex: 2,
            ),
            Text(
              locale.touchToExplore!,
              style: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .copyWith(color: Theme.of(context).scaffoldBackgroundColor),
            ),
            Spacer(),
          ],
        ),
      ),
    );
  }
}
