import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:doctoworld_kiosk/Routes/routes.dart';
import 'package:flutter/material.dart';

class Department {
  String image;
  String? title;
  int doctors;
  Department(this.image, this.title, this.doctors);
}

class OurDepartments extends StatefulWidget {
  @override
  _OurDepartmentsState createState() => _OurDepartmentsState();
}

class _OurDepartmentsState extends State<OurDepartments> {
  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    List<Department> departments = [
      Department('assets/departments/dep1.png', locale.oncologyDep, 6),
      Department('assets/departments/dep2.png', locale.ophthalmologyDep, 6),
      Department('assets/departments/dep3.png', locale.pediatricDep, 6),
      Department('assets/departments/dep4.png', locale.ctScan, 6),
      Department('assets/departments/dep5.png', locale.cardiologyDep, 6),
      Department('assets/departments/dep6.png', locale.orthopedicDep, 6),
      Department('assets/departments/dep7.png', locale.gynecologyDep, 6),
      Department('assets/departments/dep1.png', locale.oncologyDep, 6),
      Department('assets/departments/dep2.png', locale.ophthalmologyDep, 6),
      Department('assets/departments/dep3.png', locale.pediatricDep, 6),
      Department('assets/departments/dep4.png', locale.ctScan, 6),
      Department('assets/departments/dep5.png', locale.cardiologyDep, 6),
      Department('assets/departments/dep6.png', locale.orthopedicDep, 6),
      Department('assets/departments/dep7.png', locale.gynecologyDep, 6),
    ];
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.chevron_left)),
        centerTitle: true,
        title: Text(
          locale.ourDep!,
        ),
      ),
      body: FadedSlideAnimation(
        ListView.builder(
            itemCount: departments.length,
            itemBuilder: (context, index) {
              return Column(
                children: [
                  Divider(
                    thickness: 6,
                    height: 6,
                  ),
                  ListTile(
                    onTap: () {
                      Navigator.pushNamed(
                          context, PageRoutes.doctorDepartmentsPage);
                    },
                    leading: Image.asset(departments[index].image),
                    title: Text(
                      departments[index].title!,
                      style: Theme.of(context).textTheme.bodyText1!.copyWith(
                            fontSize: 16,
                          ),
                    ),
                    subtitle: Text(departments[index].doctors.toString() +
                        ' ' +
                        locale.doctors!),
                  )
                ],
              );
            }),
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
      ),
    );
  }
}
