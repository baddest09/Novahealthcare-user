import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_kiosk/AppMenu/OurDepartments/our_departments.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:doctoworld_kiosk/Theme/colors.dart';
import 'package:flutter/material.dart';

class PharmacyNearMe extends StatefulWidget {
  @override
  _PharmacyNearMeState createState() => _PharmacyNearMeState();
}

class _PharmacyNearMeState extends State<PharmacyNearMe> {
  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    List<Department> departments = [
      Department('assets/pharmacy/1a.png', locale.oncologyDep, 6),
      Department('assets/pharmacy/2.png', locale.ophthalmologyDep, 6),
      Department('assets/pharmacy/3.png', locale.pediatricDep, 6),
      Department('assets/pharmacy/4.png', locale.ctScan, 6),
      Department('assets/pharmacy/1a.png', locale.oncologyDep, 6),
      Department('assets/pharmacy/2.png', locale.ophthalmologyDep, 6),
      Department('assets/pharmacy/3.png', locale.pediatricDep, 6),
      Department('assets/pharmacy/4.png', locale.ctScan, 6),
      Department('assets/pharmacy/1a.png', locale.oncologyDep, 6),
      Department('assets/pharmacy/2.png', locale.ophthalmologyDep, 6),
      Department('assets/pharmacy/3.png', locale.pediatricDep, 6),
      Department('assets/pharmacy/4.png', locale.ctScan, 6),
    ];
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.chevron_left)),
        centerTitle: true,
        title: Text(
          locale.pharmacyNearMe!,
        ),
      ),
      body: FadedSlideAnimation(
        ListView.builder(
            itemCount: departments.length,
            itemBuilder: (context, index) {
              return Column(
                children: [
                  Divider(
                    thickness: 6,
                    height: 6,
                  ),
                  ListTile(
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 4, horizontal: 16),
                    onTap: () {
                      // Navigator.pushNamed(context, PageRoutes.doctorDepartmentsPage);
                    },
                    leading: FadedScaleAnimation(
                      Image.asset(departments[index].image),
                      durationInMilliseconds: 400,
                    ),
                    title: Text(
                      departments[index].title!,
                      style: Theme.of(context)
                          .textTheme
                          .bodyText1!
                          .copyWith(fontSize: 16),
                    ),
                    subtitle: Row(
                      children: [
                        Icon(
                          Icons.location_on,
                          size: 14,
                          color: kLightHintColor,
                        ),
                        Text(
                          ' ' + 'City Library',
                          style: Theme.of(context).textTheme.caption,
                        ),
                      ],
                    ),
                  )
                ],
              );
            }),
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
      ),
    );
  }
}
