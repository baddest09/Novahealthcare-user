import 'package:doctoworld_kiosk/AppMenu/ContactUs/contact_us.dart';
import 'package:doctoworld_kiosk/AppMenu/OurDepartments/doctor_department.dart';
import 'package:doctoworld_kiosk/AppMenu/OurDepartments/our_departments.dart';
import 'package:doctoworld_kiosk/AppMenu/OurDoctors/appointment_booked.dart';
import 'package:doctoworld_kiosk/AppMenu/OurDoctors/book_appointment.dart';
import 'package:doctoworld_kiosk/AppMenu/OurDoctors/doctor_info.dart';
import 'package:doctoworld_kiosk/AppMenu/OurDoctors/doctor_review.dart';
import 'package:doctoworld_kiosk/AppMenu/OurDoctors/list_of_doctors.dart';
import 'package:doctoworld_kiosk/AppMenu/OurDoctors/our_doctors.dart';
import 'package:doctoworld_kiosk/AppMenu/PharmacyNearMe/pharmacy_near_me.dart';
import 'package:doctoworld_kiosk/AppMenu/app_menu.dart';
import 'package:doctoworld_kiosk/AppMenu/home_page.dart';
import 'package:doctoworld_kiosk/Auth/Login/login.dart';
import 'package:flutter/material.dart';

class PageRoutes {
  static const String loginPage = 'login_page';
  static const String homePage = 'home_page';
  static const String appMenu = 'app_menu';
  static const String ourDoctorsPage = 'our_doctors';
  static const String listOfDoctors = 'list_of_doctors';
  static const String doctorInfoPage = 'doctor_info';
  static const String doctorReviewPage = 'doctor_review';
  static const String bookAppointmentPage = 'book_appointment';
  static const String appointmentBookedPage = 'appointment_booked';
  static const String ourDepartmentsPage = 'our_departments';
  static const String doctorDepartmentsPage = 'doctor_department';
  static const String pharmacyNearMe = 'pharmacy_near_me';
  static const String contactUsPage = 'contact_us';

  Map<String, WidgetBuilder> routes() {
    return {
      loginPage: (context) => LoginUI(),
      homePage: (context) => HomePage(),
      appMenu: (context) => AppMenu(),
      ourDoctorsPage: (context) => OurDoctors(),
      listOfDoctors: (context) => DoctorsPage(),
      doctorInfoPage: (context) => DoctorInfo(),
      doctorReviewPage: (context) => DoctorReviewPage(),
      bookAppointmentPage: (context) => BookAppointmentPage(),
      appointmentBookedPage: (context) => AppointmentBooked(),
      ourDepartmentsPage: (context) => OurDepartments(),
      doctorDepartmentsPage: (context) => DoctorsDepartmentsPage(),
      pharmacyNearMe: (context) => PharmacyNearMe(),
      contactUsPage: (context) => ContactUsPage(),
    };
  }
}
