import 'package:animation_wrappers/animation_wrappers.dart';
// import 'package:buy_this_app/buy_this_app.dart';
import 'package:doctoworld_kiosk/Auth/login_navigator.dart';
import 'package:doctoworld_kiosk/Components/custom_button.dart';
import 'package:doctoworld_kiosk/Components/entry_field.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:doctoworld_kiosk/Theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Config/app_config.dart';

class LoginUI extends StatefulWidget {
  @override
  _LoginUIState createState() => _LoginUIState();
}

class _LoginUIState extends State<LoginUI> {
  @override
  void initState() {
    super.initState();
    _checkForBuyNow();
  }

  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    return Scaffold(
      body: FadedSlideAnimation(
        Stack(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Spacer(
                    flex: 4,
                  ),
                  Image.asset(
                    'assets/app_name.png',
                    scale: 2.5,
                  ),
                  Spacer(
                    flex: 2,
                  ),
                  Text(
                    locale.enterYourRegistered!.toUpperCase() +
                        '\n' +
                        locale.phoneNumberToContinue!.toUpperCase(),
                    style: Theme.of(context)
                        .textTheme
                        .bodyText1!
                        .copyWith(letterSpacing: 1),
                  ),
                  Spacer(),
                  EntryField(
                    label: locale.phoneNumber!.toUpperCase(),
                    textEditingController:
                        TextEditingController(text: '+1 987 654 3210'),
                    prefixIcon: Icon(
                      Icons.phone_android,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                  SizedBox(
                    height: 12,
                  ),
                  Padding(
                    padding: const EdgeInsetsDirectional.only(start: 34.0),
                    child: Text(
                      locale.wellSendVerificationCode!,
                      style: Theme.of(context)
                          .textTheme
                          .caption!
                          .copyWith(color: kLightHintColor),
                    ),
                  ),
                  Spacer(
                    flex: 4,
                  ),
                ],
              ),
            ),
            Align(
                alignment: Alignment.bottomCenter,
                child: CustomButton(
                    text: locale.continuee,
                    onTap: () => Navigator.pushNamed(
                          context,
                          LoginRoutes.verification,
                        ))),
          ],
        ),
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
      ),
    );
  }

  void _checkForBuyNow() async {
    // SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    // if (!sharedPreferences.containsKey("key_buy_this_shown") &&
    //     AppConfig.isDemoMode) {
    //   Future.delayed(Duration(seconds: 10), () async {
    //     if (mounted) {
    //       BuyThisApp.showSubscribeDialog(context);
    //       sharedPreferences.setBool("key_buy_this_shown", true);
    //     }
    //   });
    // }
  }
}
