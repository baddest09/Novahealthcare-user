import 'package:animation_wrappers/animation_wrappers.dart';
import 'package:doctoworld_kiosk/Components/custom_button.dart';
import 'package:doctoworld_kiosk/Components/entry_field.dart';
import 'package:doctoworld_kiosk/Locale/locale.dart';
import 'package:flutter/material.dart';

class VerificationUI extends StatefulWidget {
  final VoidCallback onVerificationDone;

  const VerificationUI(this.onVerificationDone);

  @override
  _VerificationUIState createState() => _VerificationUIState();
}

class _VerificationUIState extends State<VerificationUI> {
  @override
  Widget build(BuildContext context) {
    var locale = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.chevron_left)),
        actions: [
          Center(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            child: Text(
              '0:20 ' + locale.min!,
              style: Theme.of(context)
                  .textTheme
                  .caption!
                  .copyWith(fontSize: 16, fontWeight: FontWeight.w500),
            ),
          ))
        ],
      ),
      body: FadedSlideAnimation(
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Spacer(
              flex: 8,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 28.0),
              child: Text(
                locale.enterVerificationCode!.toUpperCase() +
                    '\n' +
                    locale.hasBeenSentOnYourGiven!.toUpperCase(),
                style: Theme.of(context)
                    .textTheme
                    .bodyText1!
                    .copyWith(letterSpacing: 1),
              ),
            ),
            Spacer(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: EntryField(
                label: locale.enterVerificationCode!.toUpperCase(),
                textEditingController: TextEditingController(text: '587462'),
              ),
            ),
            Spacer(
              flex: 12,
            ),
            CustomButton(text: locale.submit, onTap: widget.onVerificationDone)
          ],
        ),
        beginOffset: Offset(0, 0.3),
        endOffset: Offset(0, 0),
        slideCurve: Curves.linearToEaseOut,
      ),
    );
  }
}
