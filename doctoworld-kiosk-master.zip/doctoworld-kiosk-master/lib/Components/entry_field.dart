import 'package:doctoworld_kiosk/Theme/colors.dart';
import 'package:flutter/material.dart';

class EntryField extends StatelessWidget {
  final TextEditingController? textEditingController;
  final String? label;
  final Icon? prefixIcon;

  const EntryField({this.textEditingController, this.label, this.prefixIcon});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        prefixIcon ?? SizedBox.shrink(),
        SizedBox(
          width: 12,
        ),
        Expanded(
          child: TextFormField(
            controller: textEditingController,
            decoration: InputDecoration(
                labelText: label,
                labelStyle: Theme.of(context)
                    .textTheme
                    .button!
                    .copyWith(color: kTextFieldLabelColor, height: 1.5)),
          ),
        ),
      ],
    );
  }
}
