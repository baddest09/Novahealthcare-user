import 'package:flutter/material.dart';

class CustomButton extends StatelessWidget {
  final String? text;
  final Function? onTap;

  const CustomButton({this.text, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap as void Function()?,
      child: Container(
        color: Theme.of(context).primaryColor,
        height: 60,
        width: double.infinity,
        child: Center(child: Text(text!, style: Theme.of(context).textTheme.button!.copyWith(fontSize: 16),)),
      ),
    );
  }
}
