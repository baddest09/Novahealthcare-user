import 'package:doctoworld_kiosk/Theme/colors.dart';
import 'package:flutter/material.dart';

class EntryField2 extends StatelessWidget {
  final TextEditingController? textEditingController;
  final String? label;
  final String? hint;

  const EntryField2({this.textEditingController, this.label, this.hint});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(width: 12,),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label!, style: Theme.of(context).textTheme.caption!.copyWith(fontSize: 12, fontWeight: FontWeight.w700),),
              TextFormField(
                controller: textEditingController,
                decoration: InputDecoration(
                  hintText: hint,
                    labelStyle: Theme.of(context).textTheme.button!.copyWith(color: kTextFieldLabelColor)
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
