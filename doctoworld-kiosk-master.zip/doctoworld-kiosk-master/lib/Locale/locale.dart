import 'package:doctoworld_kiosk/Locale/Languages/italian.dart';
import 'package:doctoworld_kiosk/Locale/Languages/swahili.dart';
import 'package:doctoworld_kiosk/Locale/Languages/turkish.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:doctoworld_kiosk/Locale/Languages/english.dart';

import '../Config/app_config.dart';
import 'Languages/arabic.dart';
import 'Languages/french.dart';
import 'Languages/german.dart';
import 'Languages/indonesian.dart';
import 'Languages/portuguese.dart';
import 'Languages/romanian.dart';
import 'Languages/spanish.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static Map<String, Map<String, String>> _localizedValues = {
    'en': english(),
    'ar': arabic(),
    'pt': portuguese(),
    'fr': french(),
    'id': indonesian(),
    'es': spanish(),
    'tk': turkish(),
    'sw': swahili(),
    'it': italian(),
    "de": german(),
    "ro": romanian(),
  };

  String? get contactUs {
    return _localizedValues[locale.languageCode]!['contactUs'];
  }

  String? get howMayWe {
    return _localizedValues[locale.languageCode]!['howMayWe'];
  }

  String? get helpYou {
    return _localizedValues[locale.languageCode]!['helpYou'];
  }

  String? get letUsKnowYourQueriesFeedbacks {
    return _localizedValues[locale.languageCode]!
        ['letUsKnowYourQueriesFeedbacks'];
  }

  String? get callUs {
    return _localizedValues[locale.languageCode]!['callUs'];
  }

  String? get emailUs {
    return _localizedValues[locale.languageCode]!['emailUs'];
  }

  String? get cardiologyDepartment {
    return _localizedValues[locale.languageCode]!['cardiologyDepartment'];
  }

  String? get cardiacSurgeon {
    return _localizedValues[locale.languageCode]!['cardiacSurgeon'];
  }

  String? get exp {
    return _localizedValues[locale.languageCode]!['exp'];
  }

  String? get years {
    return _localizedValues[locale.languageCode]!['years'];
  }

  String? get fees {
    return _localizedValues[locale.languageCode]!['fees'];
  }

  String? get oncologyDep {
    return _localizedValues[locale.languageCode]!['oncologyDep'];
  }

  String? get ophthalmologyDep {
    return _localizedValues[locale.languageCode]!['ophthalmologyDep'];
  }

  String? get pediatricDep {
    return _localizedValues[locale.languageCode]!['pediatricDep'];
  }

  String? get ctScan {
    return _localizedValues[locale.languageCode]!['ctScan'];
  }

  String? get cardiologyDep {
    return _localizedValues[locale.languageCode]!['cardiologyDep'];
  }

  String? get orthopedicDep {
    return _localizedValues[locale.languageCode]!['orthopedicDep'];
  }

  String? get gynecologyDep {
    return _localizedValues[locale.languageCode]!['gynecologyDep'];
  }

  String? get ourDep {
    return _localizedValues[locale.languageCode]!['ourDep'];
  }

  String? get doctors {
    return _localizedValues[locale.languageCode]!['doctors'];
  }

  String? get appointmentBooked {
    return _localizedValues[locale.languageCode]!['appointmentBooked'];
  }

  String? get yourAppointmentHas {
    return _localizedValues[locale.languageCode]!['yourAppointmentHas'];
  }

  String? get beenBooked {
    return _localizedValues[locale.languageCode]!['beenBooked'];
  }

  String? get appointmentDetails {
    return _localizedValues[locale.languageCode]!['appointmentDetails'];
  }

  String? get hasBeenSentOnYourGiven {
    return _localizedValues[locale.languageCode]!['hasBeenSentOnYourGiven'];
  }

  String? get number {
    return _localizedValues[locale.languageCode]!['number'];
  }

  String? get home {
    return _localizedValues[locale.languageCode]!['home'];
  }

  String? get selectDateTime {
    return _localizedValues[locale.languageCode]!['selectDateTime'];
  }

  String? get selectDate {
    return _localizedValues[locale.languageCode]!['selectDate'];
  }

  String? get june2020 {
    return _localizedValues[locale.languageCode]!['june2020'];
  }

  String? get selectTime {
    return _localizedValues[locale.languageCode]!['selectTime'];
  }

  String? get am {
    return _localizedValues[locale.languageCode]!['am'];
  }

  String? get appointmentFor {
    return _localizedValues[locale.languageCode]!['appointmentFor'];
  }

  String? get egHeart {
    return _localizedValues[locale.languageCode]!['egHeart'];
  }

  String? get fullName {
    return _localizedValues[locale.languageCode]!['fullName'];
  }

  String? get enterOTPSentOnYour {
    return _localizedValues[locale.languageCode]!['enterOTPSentOnYour'];
  }

  String? get givenNumber {
    return _localizedValues[locale.languageCode]!['givenNumber'];
  }

  String? get phoneNumber {
    return _localizedValues[locale.languageCode]!['phoneNumber'];
  }

  String? get enterOTP {
    return _localizedValues[locale.languageCode]!['enterOTP'];
  }

  String? get wellSendVerificationCode {
    return _localizedValues[locale.languageCode]!['wellSendVerificationCode'];
  }

  String? get sendVerificationCode {
    return _localizedValues[locale.languageCode]!['sendVerificationCode'];
  }

  String? get confirmBooking {
    return _localizedValues[locale.languageCode]!['confirmBooking'];
  }

  String? get experience {
    return _localizedValues[locale.languageCode]!['experience'];
  }

  String? get yearsPascal {
    return _localizedValues[locale.languageCode]!['yearsPascal'];
  }

  String? get consultancyFees {
    return _localizedValues[locale.languageCode]!['consultancyFees'];
  }

  String? get feedbacks {
    return _localizedValues[locale.languageCode]!['feedbacks'];
  }

  String? get availability {
    return _localizedValues[locale.languageCode]!['availability'];
  }

  String? get services {
    return _localizedValues[locale.languageCode]!['services'];
  }

  String? get hypertensionTreatment {
    return _localizedValues[locale.languageCode]!['hypertensionTreatment'];
  }

  String? get copdTreatment {
    return _localizedValues[locale.languageCode]!['copdTreatment'];
  }

  String? get diabetesManagement {
    return _localizedValues[locale.languageCode]!['diabetesManagement'];
  }

  String? get ecg {
    return _localizedValues[locale.languageCode]!['ecg'];
  }

  String? get obesityTreatment {
    return _localizedValues[locale.languageCode]!['obesityTreatment'];
  }

  String? get more {
    return _localizedValues[locale.languageCode]!['more'];
  }

  String? get sprecifications {
    return _localizedValues[locale.languageCode]!['sprecifications'];
  }

  String? get generalPhysician {
    return _localizedValues[locale.languageCode]!['generalPhysician'];
  }

  String? get familyPhysician {
    return _localizedValues[locale.languageCode]!['familyPhysician'];
  }

  String? get cardiologist {
    return _localizedValues[locale.languageCode]!['cardiologist'];
  }

  String? get consultantPhysician {
    return _localizedValues[locale.languageCode]!['consultantPhysician'];
  }

  String? get diabetologist {
    return _localizedValues[locale.languageCode]!['diabetologist'];
  }

  String? get bookAppointmentNow {
    return _localizedValues[locale.languageCode]!['bookAppointmentNow'];
  }

  String? get coldFever {
    return _localizedValues[locale.languageCode]!['coldFever'];
  }

  String? get headache {
    return _localizedValues[locale.languageCode]!['headache'];
  }

  String? get reviews {
    return _localizedValues[locale.languageCode]!['reviews'];
  }

  String? get averageReviews {
    return _localizedValues[locale.languageCode]!['averageReviews'];
  }

  String? get averageReview {
    return _localizedValues[locale.languageCode]!['averageReview'];
  }

  String? get visitedFor {
    return _localizedValues[locale.languageCode]!['visitedFor'];
  }

  String? get surgery {
    return _localizedValues[locale.languageCode]!['surgery'];
  }

  String? get ourDoctors {
    return _localizedValues[locale.languageCode]!['ourDoctors'];
  }

  String? get findBySpecialities {
    return _localizedValues[locale.languageCode]!['findBySpecialities'];
  }

  String? get listOfSpecialities {
    return _localizedValues[locale.languageCode]!['listOfSpecialities'];
  }

  String? get pharmacyNearMe {
    return _localizedValues[locale.languageCode]!['pharmacyNearMe'];
  }

  String? get our {
    return _localizedValues[locale.languageCode]!['our'];
  }

  String? get departments {
    return _localizedValues[locale.languageCode]!['departments'];
  }

  String? get pharmacy {
    return _localizedValues[locale.languageCode]!['pharmacy'];
  }

  String? get nearMe {
    return _localizedValues[locale.languageCode]!['nearMe'];
  }

  String? get contact {
    return _localizedValues[locale.languageCode]!['contact'];
  }

  String? get us {
    return _localizedValues[locale.languageCode]!['us'];
  }

  String? get welcome {
    return _localizedValues[locale.languageCode]!['welcome'];
  }

  String? get letUsGuide {
    return _localizedValues[locale.languageCode]!['letUsGuide'];
  }

  String? get touchToExplore {
    return _localizedValues[locale.languageCode]!['touchToExplore'];
  }

  String? get enterYourRegistered {
    return _localizedValues[locale.languageCode]!['enterYourRegistered'];
  }

  String? get phoneNumberToContinue {
    return _localizedValues[locale.languageCode]!['phoneNumberToContinue'];
  }

  String? get wellSendVerification {
    return _localizedValues[locale.languageCode]!['wellSendVerification'];
  }

  String? get continuee {
    return _localizedValues[locale.languageCode]!['continuee'];
  }

  String? get min {
    return _localizedValues[locale.languageCode]!['min'];
  }

  String? get enterVerificationCodeSent {
    return _localizedValues[locale.languageCode]!['enterVerificationCodeSent'];
  }

  String? get enterVerificationCode {
    return _localizedValues[locale.languageCode]!['enterVerificationCode'];
  }

  String? get submit {
    return _localizedValues[locale.languageCode]!['submit'];
  }

  String? get changeLanguage {
    return _localizedValues[locale.languageCode]!['changeLanguage'];
  }

  static List<Locale> getSupportedLocales() {
    List<Locale> toReturn = [];
    for (String langCode in AppConfig.languagesSupported.keys) {
      toReturn.add(Locale(langCode));
    }
    return toReturn;
  }
}

class AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) =>
      AppConfig.languagesSupported.keys.contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(AppLocalizations(locale));
  }

  @override
  bool shouldReload(AppLocalizationsDelegate old) => false;
}
